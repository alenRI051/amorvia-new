Amorvia Patch — HUD + Choices + Cleanup
=======================================
See Nova’s instructions in ChatGPT for details.
