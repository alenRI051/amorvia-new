Amorvia Scenarios Bundle
========================
Generated: 2025-09-08T19:58:12.795305Z

This bundle adds four playable v2 scenarios. Unzip at the repo root.

Files
-----
- public/data/visitor.v2.json
- public/data/step-parenting-conflicts.v2.json
- public/data/cultural-or-religious-difference.v2.json
- public/data/lgbtq-relationship-challenges.v2.json
- public/data/v2-index.delta.json   (append these entries to your v2-index.json)

Apply
-----
unzip -o amorvia-scenarios-bundle.zip -d .

# Append the delta to public/data/v2-index.json manually or via jq:
jq '.scenarios += (input)' public/data/v2-index.json public/data/v2-index.delta.json > public/data/v2-index.merged.json && \
mv public/data/v2-index.merged.json public/data/v2-index.json

git add public/data/*.v2.json public/data/v2-index.json
git commit -m "feat(content): add 3 new scenarios + update index"
git pull --rebase origin main
git push

Validate
--------
npx --yes -p ajv-formats ajv-cli@5 validate \  -s public/schema/scenario.v2.schema.json \  -d 'public/data/*.v2.json' \  --spec=draft2020 \  -c ajv-formats \  --strict=false
